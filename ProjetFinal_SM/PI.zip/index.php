<?php
$title=<<<HTML
<title>Accueil</title>
HTML;

$content=<<<HTML
<section id="banner" class="major">
<div class="inner">
<header class="major">
<h1>L'achat de billet simplifié</h1>
</header>
<div class="content">
<p>Vous avez des questions pour nous?</p>
<ul class="actions">
<li><a href="contact.html" class="button next scrolly">Contacter nous</a></li>
</ul>
</div>
</div>
</section>

<!-- Main -->
<div id="main">
					
					
<!-- About us -->
<section>
<div class="inner">
<header class="major">
<h2>À Propos De Nous</h2>
</header>
<p>Billetterie HTT est un site web ...</p>
<ul class="actions">
<li><a href="about-us.html" class="button next">En apprendre plus</a></li>
</ul>
</div>
</section>
					
<!-- Featured Products -->
<div class="inner">
<header class="major">
<h2>Événements populaires</h2>
</header>
<section class="tiles">
<article>
<span class="image">
<img src="images/Show1.jpg" alt="" />
</span>
<header class="major">
<h3>The Weeknd</h3>

<p><strong>$79.00</strong></p>

<p>Concert de The Weeknd</p>

<div class="major-actions">
<a href="product-details.html" class="button small next">Détails</a>
</div>
</header>
</article>
<article>
<span class="image">
<img src="images/show2.png" alt="" />
</span>
<header class="major">
<h3>Canadien De Montreal</h3>

<p><strong>$179.00</strong></p>

<p>Assister à la premiere partie du ch </p>

<div class="major-actions">
<a href="product-details.html" class="button small next">Détails</a>
</div>
</header>
</article>
<article>
<span class="image">
<img src="images/show3.jpg" alt="" />
</span>
<header class="major">
<h3>LES BÂTISSEURS D’EMPIRE</h3>

<p><del>$50.00</del> <strong> $35.00</strong></p>

<p>Piece de theatre</p>

<div class="major-actions">
<a href="product-details.html" class="button small next">Détails</a>
</div>
</header>
</article>
								
</section>
</div>
HTML;
	include "master.php";
?>